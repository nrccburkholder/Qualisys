/*

Sprint 72 SQLCMD Script for Wonderwoman/Cyclone/Mars

\Sprint_docs\Sprint72_docs\S72_WonderwomanCycloneMars.sql

*/

:r "\ATLASRelease71&72\Sprint72_docs\S72_ATL-1443 Update Study Data Structure Process [QP_Load].sql"

--:r "\ATLASRelease71&72\Sprint72_docs\S72 ATL-1430 Update DTS Packages to Use OASEligibleSurg.sql" --hold for training/next quarter

--:r "\ATLASRelease71&72\Sprint72_docs\S72_ATL-1429 Update OAS CPT Code Exclusions [QP_Load].sql" --hold for training/next quarter

--:r "\ATLASRelease71&72\Sprint72_docs\S72_ATL-1078 Update the QLoader CPT codes function.sql" --hold for training/next quarter