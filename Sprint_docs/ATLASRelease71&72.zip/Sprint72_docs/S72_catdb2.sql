/*

Sprint 72 SQLCMD Script for CatDB2

\Sprint_docs\Sprint72_docs\S72_catdb2.sql

*/

:r "\ATLASRelease71&72\Sprint72_docs\S72_ATL-1375 ICH Bad Addr Dispos on Mixed Mode [CATDB2].sql"

