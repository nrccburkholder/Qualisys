/*

Sprint 58 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint58_docs\S58_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease57&58\Sprint58_docs\S58 ATL-718 Remove Systematic Sampling target record.sql"

:r "\ATLASRelease57&58\Sprint58_docs\S58 ATL-836 ATL-859 ACO & PQRS Standard Methodologies 2016 New Metafields.sql"

:r "\ATLASRelease57&58\Sprint58_docs\S55 ATL-683 DRG Update Rollback Process.sql"

:r "\ATLASRelease57&58\Sprint58_docs\S58 ATL-772 DRG Update Rollback UI NRC10.sql"

--Dave G already deployed :r "\ATLASRelease57&58\Sprint58_docs\S58 ATL-852 CEM.PullExportData.sql" 

--Dave G already deployed :r "\ATLASRelease57&58\Sprint58_docs\S58 ATL-852 CEM.ExportPostProcess00000014.sql"