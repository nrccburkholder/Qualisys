/*

Sprint 56 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint56_docs\S56_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease55&56\Sprint56_docs\S56 ATL-708 Phone Vendor Cancel Fix - backout.sql"

:r "\ATLASRelease55&56\Sprint56_docs\S56 ATL-715 Vovici Svc Resending Participants - Rollback.sql"

--OC Release on 9/1/2016 :r "\ATLASRelease55&56\Sprint56_docs\S56 ATL-719 OAS CAHPS Resurvey Exclusion ROLLBACK.sql"

--:r "\ATLASRelease55&56\Sprint56_docs\S56_ATL-742 datExpireUsage in ETL - NRC10 - ROLLBACK.sql"