/*

Sprint 57 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint57_docs\S57_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease57&58\Sprint57_docs\S57 ATL-194 Sampling Householding.sql"

:r "\ATLASRelease57&58\Sprint57_docs\S57 ATL-777 OAS Proxy Surveys NRC10.sql"