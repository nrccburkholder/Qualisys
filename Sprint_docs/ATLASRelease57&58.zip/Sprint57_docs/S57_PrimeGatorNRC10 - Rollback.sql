/*

Sprint 57 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\Sprint57_docs\S57_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease57&58\Sprint57_docs\S57 ATL-194 Sampling Householding - Rollback.sql"

:r "\ATLASRelease57&58\Sprint57_docs\S57 ATL-777 OAS Proxy Surveys NRC10 - ROLLBACK.sql"
