
:r "\GIT2015\Sprint_docs\Sprint37_docs\S37 US6 T1 Skip Instructions Question Variations.sql"

:r "\GIT2015\Sprint_docs\Sprint37_docs\S37_US7.1 Add Missing Caregiver disposition_QP_Prod.sql"

:r "\GIT2015\Sprint_docs\Sprint37_docs\S37_US7.2 QCL_Samp_ScheduleSampleSetGeneration.sql"