/*

Sprint 72 SQLCMD Rollback Script for CatDB2

\Sprint_docs\Sprint72_docs\S72_catdb2 - Rollback.sql

*/

:r "\ATLASRelease71&72\Sprint72_docs\S72_ATL-1375 ICH Bad Addr Dispos on Mixed Mode [CATDB2] - Rollback.sql"

