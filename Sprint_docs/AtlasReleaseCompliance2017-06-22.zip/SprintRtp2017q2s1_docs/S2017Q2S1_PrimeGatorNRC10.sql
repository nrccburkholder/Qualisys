/*

Sprint 2017 Q2 S1 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q2s1_docs\S2017Q2S1_PrimeGatorNRC10.sql

*/

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s1_docs\RTP-2431 DRG Updated Non-Sampled Records.sql" 

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s1_docs\RTP-2565 HCAHPS Household Before Sample Selection.sql" 

