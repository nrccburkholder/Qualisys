/*

Sprint 2017 Q2 S2 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q2s2_docs\S2017Q2S2_PrimeGatorNRC10.sql

*/

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\ATL-1419 Resurvey Exclusion for Returns Only.sql" 

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\RTP-1437 Disallow sampleset scheduling for RT surveys.sql" 

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\RTP-2402 ODSDB Select Resurvey Settings.sql" 


