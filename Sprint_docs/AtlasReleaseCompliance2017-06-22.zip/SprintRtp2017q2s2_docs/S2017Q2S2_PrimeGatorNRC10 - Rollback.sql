/*

Sprint 2017 Q2 S2 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q2s2_docs\S2017Q2S2_PrimeGatorNRC10 - Rollback.sql

*/

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\ATL-1419 Resurvey Exclusion for Returns Only - Rollback.sql" 

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\RTP-1437 Disallow sampleset scheduling for RT surveys_rollback.sql" 

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\RTP-2402 ODSDB Select Resurvey Settings - Rollback.sql" 


