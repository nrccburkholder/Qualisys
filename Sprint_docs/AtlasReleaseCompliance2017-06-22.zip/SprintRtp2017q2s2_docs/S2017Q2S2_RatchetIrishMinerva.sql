/*

Sprint 2017 Q2 S2 SQLCMD Script for Ratchet/Irish/Minerva

\Sprint_docs\SprintRtp2017q2s2_docs\S2017Q2S2_RatchetIrishMinerva.sql

*/

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\RTP-2348 QLoader GetICD10 Functions Modification (QP_Dataload).sql" 

