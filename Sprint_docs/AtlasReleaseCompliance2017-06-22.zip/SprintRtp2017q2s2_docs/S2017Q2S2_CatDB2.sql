/*

Sprint 2017 Q2 S2 SQLCMD Script for CatDB2

\Sprint_docs\SprintRtp2017q2s2_docs\S2017Q2S2_CatDB2.sql

*/

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\RTP-2340 OAS Submission File Update.sql" 

:r "\AtlasReleaseCompliance2017-06-22\SprintRtp2017q2s2_docs\RTP-2341 Hospice CAHPS Submission File 3.1.sql" 
