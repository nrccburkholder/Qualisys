/*

Sprint 51 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint51_docs\S51_catsql01-catdb2.sql

*/


:r "\ATLASRelease51&52\Sprint51_docs\S51 ATL-409 Hospice Language Speak changes for Submission CEM.sql"

:r "\ATLASRelease51&52\Sprint51_docs\S51 ATL-463 OAS first Submission Compliance Support.sql"
