/*

Sprint 47 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint47_docs\S47_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease47&48\Sprint47_docs\S43_US8 Disposition Log Days ROLLBACK.sql"

:r "\ATLASRelease47&48\Sprint47_docs\S47 ATL-225 Refactor Num Attempts in Catalyst ETL_Rollback.sql"

--:r "\ATLASRelease47&48\Sprint47_docs\S47 ATL-226 Personalization Code 31 Analysis - Rollback.sql"

:r "\ATLASRelease47&48\Sprint47_docs\S47 ATL-259 CSP_GetQuestionFormExtractData_ROLLBACK.sql"
