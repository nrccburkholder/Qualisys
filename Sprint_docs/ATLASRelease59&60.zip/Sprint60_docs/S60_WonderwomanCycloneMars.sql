/*

Sprint 60 SQLCMD Script for Wonderwoman/Cyclone/Mars

\Sprint_docs\Sprint60_docs\S60_WonderwomanCycloneMars.sql

*/

:r "\ATLASRelease59&60\Sprint60_docs\S60_ATL-943 G code CPT validation report warning for OAS.sql"

