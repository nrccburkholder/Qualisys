/*

Sprint 60 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint60_docs\S60_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease59&60\Sprint60_docs\S60 ATL-987 SV_CAHPS_SamplePeriods Disable for CIHI.sql"

:r "\ATLASRelease59&60\Sprint60_docs\S60 ATL-974 DRG Update-Rollback modification.sql"

:r "\ATLASRelease59&60\Sprint60_docs\S60 ATL-972 Add a AllowAutoSample bit field to ClientGroup.sql"

