/*

Sprint 59 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint59_docs\S59_catsql01-catdb2.sql

*/

:r "\ATLASRelease59&60\Sprint59_docs\S59 ATL-871 Processing for ACO_PQRS Bad Addr & Bad Phone CATDB.sql"

:r "\ATLASRelease59&60\Sprint59_docs\S59 ATL-864 Update ACO & PQRS CEM Templates.sql"

