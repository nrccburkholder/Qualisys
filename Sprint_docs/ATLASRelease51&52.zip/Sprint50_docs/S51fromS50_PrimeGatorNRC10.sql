/*

Sprint 50 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint50_docs\S51fromS50_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease51&52\Sprint50_docs\S50 ATL-278 CA Web Survey Migration.sql"