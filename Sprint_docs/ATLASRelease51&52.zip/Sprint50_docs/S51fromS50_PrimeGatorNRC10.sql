/*

Sprint 50 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint50_docs\S50_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease49&50\Sprint50_docs\S50 ATL-278 CA Web Survey Migration.sql"