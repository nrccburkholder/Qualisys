/*

Sprint 50 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint50_docs\S50_catsql01-catdb2 - Rollback.sql

*/


:r "\ATLASRelease49&50\Sprint50_docs\S50 ATL-414 Create OAS template_rollback.sql"


