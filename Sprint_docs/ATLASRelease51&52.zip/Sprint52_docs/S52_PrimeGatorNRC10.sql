/*

Sprint 52 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint52_docs\S52_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease51&52\Sprint52_docs\S52 ATL-530 HCAHPS Update File Disposition.sql"

--:r "\ATLASRelease51&52\Sprint52_docs\ATL-537 CheckForMostCompleteUsablePartials.sql"