/*

Sprint 51 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint48_docs\S51from48_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease51&52\Sprint48_docs\S48 ATL-157 Implement OAS Systematic Sampling Algorithm.sql"

:r "\ATLASRelease51&52\Sprint48_docs\S48 ATL-328 HHCAHPS Multiple Files Same CCN Minerva.sql"
 