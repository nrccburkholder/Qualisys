/*

Sprint 51 SQLCMD Script for Ratchet/Irish/Minerva

\Sprint_docs\Sprint51_docs\S51_RatchetIrishMinerva - Rollback.sql

*/

:r "\ATLASRelease51&52\Sprint51_docs\S51 ATL-363 Process Multiple Files in HH Importer - QP_DATALOAD -- ROLLBACK.sql"

