/*

Sprint 53 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint53_docs\S52from53_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease51&52\Sprint53_docs\S53 ATL-578 Exclude OAS survey type CCN Sampling Lock.sql"

:r "\ATLASRelease51&52\Sprint53_docs\S53_DebugScriptsForDana.sql"

