/*

Sprint 53 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint53_docs\S53_PrimeGatorNRC10 - Rollback.sql

*/

--:r "\ATLASRelease53&54\Sprint53_docs\"
