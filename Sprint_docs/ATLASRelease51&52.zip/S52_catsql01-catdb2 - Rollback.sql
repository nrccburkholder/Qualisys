/*

Sprint 52 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint52_docs\S52_catsql01-catdb2 - Rollback.sql

*/

:r "\ATLASRelease51&52\Sprint52_docs\S52 ATL-505 ICH Nondels with Blank Dispo fix -- ROLLBACK.sql"


