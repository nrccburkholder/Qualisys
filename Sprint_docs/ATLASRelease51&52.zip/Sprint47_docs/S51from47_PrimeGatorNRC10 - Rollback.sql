/*

Sprint 51 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint47_docs\S51from47_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease51&52\Sprint47_docs\S47 ATL-157 Systematic Outgo and Proportion tables_rollback.sql"

:r "\ATLASRelease51&52\Sprint47_docs\S47 ATL-242 DB stored procedures for OAS sampling_Rollback.sql"
