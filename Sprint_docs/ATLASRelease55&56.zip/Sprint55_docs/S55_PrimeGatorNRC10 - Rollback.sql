/*

Sprint 55 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\Sprint55_docs\S55_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease55&56\Sprint55_docs\S55 ATL-180 No Seeded Mailings for Phone Steps ROLLBACK.sql"

:r "\ATLASRelease55&56\Sprint55_docs\S55 ATL-351 Householding by CCN_rollback.sql"

:r "\ATLASRelease55&56\Sprint55_docs\S55 ATL-683 DRG Update Rollback Process ROLLBACK.sql"

--:r "\ATLASRelease55&56\Sprint55_docs\S55 ATL-685 DRG update disallowed for submitted data  ROLLBACK.sql"