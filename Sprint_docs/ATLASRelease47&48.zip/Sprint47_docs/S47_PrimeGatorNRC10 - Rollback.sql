/*

Sprint 47 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint47_docs\S47_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease47&48\Sprint47_docs\S43_US8 Disposition Log Days ROLLBACK.sql"


