/*

Sprint 46 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint46_docs\S46_catsql01-catdb2.sql

*/


:r "\ATLASRelease47&48\Sprint47_docs\S47 ATL-262 ETL_LoadSamplePopulationDispositionLogRecords_ROLLBACK.sql"


