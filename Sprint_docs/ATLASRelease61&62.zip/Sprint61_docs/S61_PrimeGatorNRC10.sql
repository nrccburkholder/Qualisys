/*

Sprint 61 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint61_docs\S61_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease61&62\Sprint61_docs\S61 ATL-962 Modify ICH Submission Skip Coding.sql"

:r "\ATLASRelease61&62\Sprint61_docs\S61 ATL-1000 DRG Update-LoggedBy NRC10.sql"

:r "\ATLASRelease61&62\Sprint61_docs\S61 ATL-1035 HCAHPS Proxy Handling NRC10.sql"
