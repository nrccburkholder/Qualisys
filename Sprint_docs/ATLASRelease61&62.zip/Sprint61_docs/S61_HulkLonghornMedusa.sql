/*

Sprint 61 SQLCMD Script for Hulk/Longhorn/Medusa

\Sprint_docs\Sprint61_docs\S61_HulkLonghornMedusa.sql

*/

:r "\ATLASRelease61&62\Sprint61_docs\S61 ATL-1000 Evaluate Dispose from DRG Updates Medusa.sql"

