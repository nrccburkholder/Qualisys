/*

Sprint 61 SQLCMD Script for CatSql01-CatDB2

\Sprint_docs\Sprint61_docs\S61_catsql01-catdb2 - Rollback.sql

*/

:r "\ATLASRelease61&62\Sprint61_docs\S61 ATL-1035 HCAHPS Proxy Handling CATDB - ROLLBACK.sql"

