/*

Sprint 43 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint43_docs\S43_PrimeGatorNRC10 - ROLLBACK.sql

Chris Burkholder

*/

:r "\ATLASRelease43&44\Sprint43_docs\S43_US8 Disposition Log Days ROLLBACK.sql"

--:r "\ATLASRelease43&44\Sprint43_docs\S43_US13.2_ICH_Methodologies NRC10 ROLLBACK.sql"
