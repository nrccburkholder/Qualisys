/*

Sprint 43 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint43_docs\S43_PrimeGatorNRC10.sql

Chris Burkholder

*/

:r "\ATLASRelease43&44\Sprint43_docs\S43_US8 Disposition Log Days.sql"

--:r "\ATLASRelease43&44\Sprint43_docs\S43_US13.2_ICH_Methodologies NRC10.sql" -- scheduled for early release 

--:r "\ATLASRelease43&44\Sprint43_docs\S43_US6.8 Sutter Sampling.sql" -- this has already been deployed
