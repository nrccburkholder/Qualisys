/*

Sprint 44 SQLCMD Script for Ratchet/Irish/Minerva

\Sprint_docs\Sprint44_docs\S44_RatchetIrishMinerva - Rollback.sql

Chris Burkholder

*/

:r "\ATLASRelease43&44\Sprint44_docs\S44_11.1_CGCAHPSDispositions MINERVA ROLLBACK.sql"  

:r "\ATLASRelease43&44\Sprint44_docs\S44_US14 Update Practice Site Submission File Proc - QP_Comments - ROLLBACK.sql"

:r "\ATLASRelease43&44\Sprint44_docs\S45_US15 CG Update Patient Submission Procs ROLLBACK.sql"

