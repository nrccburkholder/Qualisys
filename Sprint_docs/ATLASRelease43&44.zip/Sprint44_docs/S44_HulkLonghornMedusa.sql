/*

Sprint 44 SQLCMD Script for Hulk/Longhorn/Medusa

\Sprint_docs\Sprint44_docs\S44_HulkLonghornMedusa.sql

Chris Burkholder

*/

:r "\ATLASRelease43&44\Sprint44_docs\S44_11.1_CGCAHPSDispositions MEDUSA.sql"

:r "\ATLASRelease43&44\Sprint44_docs\S44_US14 Update Practice Site Submission File Proc - QP_Comments.sql"

:r "\ATLASRelease43&44\Sprint44_docs\S45_US15 CG Update Patient Submission Procs.sql"

:r "\ATLASRelease43&44\Sprint44_docs\S44_US13 Update Group Submission File Proc.sql"

