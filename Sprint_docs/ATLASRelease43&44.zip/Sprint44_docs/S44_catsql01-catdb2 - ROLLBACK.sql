/*

Sprint 44 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint44_docs\S44_catsql01-catdb2.sql

ROLLBACK

*/

:r "\ATLASRelease43&44\Sprint44_docs\S44_11.2 CGCAHPSDispositions CATDB2 ROLLBACK .sql"


