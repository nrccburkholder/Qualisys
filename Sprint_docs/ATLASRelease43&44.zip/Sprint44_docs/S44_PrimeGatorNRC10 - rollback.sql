/*

Sprint 44 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint44_docs\S44_PrimeGatorNRC10 - rollback .sql

Chris Burkholder

*/

:r "\ATLASRelease43&44\Sprint44_docs\S44_11.1_CGCAHPSDispositions NRC10 ROLLBACK.sql"

:r "\ATLASRelease43&44\Sprint44_docs\S44_12 CGCAHPSCompleteness NRC10 ROLLBACK.sql"

:r "\ATLASRelease43&44\Sprint44_docs\S44_US14 Update Practice Site Submission File Proc - QP_Prod - ROLLBACK.sql"
