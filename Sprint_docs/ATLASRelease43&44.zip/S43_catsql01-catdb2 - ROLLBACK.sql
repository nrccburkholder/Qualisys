/*

Sprint 43 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint43_docs\S43_catsql01-catdb2.sql

*/


--:r "\ATLASRelease43&44\Sprint43_docs\S43_US13.2_ICH_Methodologies CATDB2 ROLLBACK.sql


