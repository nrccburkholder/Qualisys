/*

Sprint 38 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint38_docs\S38_PrimeGatorNRC10 - Rollback.sql

Chris Burkholder

*/

:r "\ATLASRelease38&39\Sprint38_docs\S38.US1.T2 backpopulate CGCAHPS group and site tool - Rollback.sql"