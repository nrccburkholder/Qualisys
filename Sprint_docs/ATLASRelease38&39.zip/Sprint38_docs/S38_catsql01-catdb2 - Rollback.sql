/*

Sprint 38 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint38_docs\S38_catsql01-catdb2 - Rollback.sql

Chris Burkholder

*/

:r "\ATLASRelease38&39\Sprint38_docs\S38_US6.1 CEM Hospice ExportPostProcess00000008 - Rollback.sql"