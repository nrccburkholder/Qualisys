/*

Sprint 38 SQLCMD Script for Wonderwoman/Cyclone/Mars

\Sprint_docs\Sprint38_docs\S38_WonderwomanCycloneMars.sql

Chris Burkholder

*/

:r "\ATLASRelease38&39\Sprint38_docs\S38_US6.2_QLoader_Validation_Cross-month_datasets_US12.1_CountFieldsValidation.sql"