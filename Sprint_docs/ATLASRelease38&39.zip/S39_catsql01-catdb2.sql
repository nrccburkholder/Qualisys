/*

Sprint 39 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint39_docs\S39_catsql01-catdb2.sql

Chris Burkholder

*/

:r "\ATLASRelease38&39\Sprint39_docs\S39_US17.5 Hospice CAHPS 2.0 Language-Speak Question.sql"