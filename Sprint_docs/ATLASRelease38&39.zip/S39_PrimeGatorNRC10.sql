/*

Sprint 39 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint39_docs\S39_PrimeGatorNRC10.sql

Chris Burkholder

*/


:r "\ATLASRelease38&39\Sprint39_docs\S39_US17.2_ Hospice_CAHPS_2.0_Language-Speak Question.sql"
