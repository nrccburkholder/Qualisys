/*

Sprint 39 SQLCMD Script for Wonderwoman/Cyclone/Mars

\Sprint_docs\Sprint39_docs\S39_WonderwomanCycloneMars.sql

Chris Burkholder

*/


:r "\ATLASRelease38&39\Sprint39_docs\S39_R18_QLoader_LD_SaveSource.sql"