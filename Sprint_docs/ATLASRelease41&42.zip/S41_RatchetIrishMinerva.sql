/*

Sprint 41 SQLCMD Script for Ratchet/Irish/Minerva

\Sprint_docs\Sprint41_docs\S41_RatchetIrishMinerva.sql

Chris Burkholder

*/

:r "\ATLASRelease41&42\Sprint41_docs\S41_S40_US33.2 Map CCN to file type.sql"

:r "\ATLASRelease41&42\Sprint41_docs\S41_S40_US33.5 Map CCN to file type.sql"

:r "\ATLASRelease41&42\Sprint41_docs\S41_US16.1 OCS HH process update files.sql"

:r "\ATLASRelease41&42\Sprint41_docs\S41_US16.2 OCS HH process update files.sql"

:r "\ATLASRelease41&42\Sprint41_docs\S41_US16.4 OCS HH process update files.sql"

:r "\ATLASRelease41&42\Sprint41_docs\S41_US16.4.2 OCS HH process update files.sql"
