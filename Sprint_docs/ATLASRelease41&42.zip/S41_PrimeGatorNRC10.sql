/*

Sprint 41 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint41_docs\S41_PrimeGatorNRC10.sql

Chris Burkholder

*/

:r "\ATLASRelease41&42\Sprint41_docs\S41 US20 T1 OAS CAHPS Skip Instructions.sql"

:r "\ATLASRelease41&42\Sprint41_docs\S41_US21 OAS Keep Most Complete Return.sql"

