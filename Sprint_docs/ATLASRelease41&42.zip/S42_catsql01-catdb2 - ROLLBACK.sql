/*

Sprint 42 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint42_docs\S42_catsql01-catdb2.sql

ROLLBACK

*/

:r "\ATLASRelease41&42\Sprint42_docs\S42 US9 T3 OAS Dispo processing CATDB2 - Rollback.sql"

:r "\ATLASRelease41&42\Sprint42_docs\S42 US12_13  OAS ETL Updates CATDB2 ROLLBACK.sql"

