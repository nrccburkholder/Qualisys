/*

Sprint 42 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint42_docs\S42_catsql01-catdb2.sql

*/


:r "\ATLASRelease41&42\Sprint40_docs\S42 US9 T3 OAS Dispo processing CATDB2.sql"
