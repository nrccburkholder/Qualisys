/*

Sprint 42 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint42_docs\S42_PrimeGatorNRC10.sql

Chris Burkholder

*/

:r "\ATLASRelease41&42\Sprint42_docs\S42 US9 T2 OAS Dispo processing QP_PROD.sql"

:r "\ATLASRelease41&42\Sprint42_docs\S42 US12_13  OAS ETL Updates NRC10.sql"

:r "\ATLASRelease41&42\Sprint42_docs\S42_US12  ALTER PROCEDURE QCL_SelectEncounterUnitEligibility.sql"