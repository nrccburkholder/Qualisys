/*

Sprint 2017 Q2 S4 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q2s4_docs\S2017Q2S4_PrimeGatorNRC10.sql

*/

:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s4_docs\RTP-3130 create ResurveyType metafield.sql" 

:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s4_docs\RTP-2396 - Qualisys Default DQ Rules.sql" 

