/*

Sprint 2017 Q2 S3 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q2s3_docs\S2017Q2S3_PrimeGatorNRC10 - Rollback.sql

*/

:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s3_docs\RTP-2395 Sampling - re-survey exclusion rule - Rollback.sql" 

:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s3_docs\SurveyRules RT from HCAHPS - Rollback.sql" 

--:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s3_docs\ATL-1450 skip instructions are no longer Bolded - Rollback.sql" --already released
