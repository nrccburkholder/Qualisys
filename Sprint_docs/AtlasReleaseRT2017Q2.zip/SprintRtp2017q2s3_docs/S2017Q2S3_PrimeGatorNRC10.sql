/*

Sprint 2017 Q2 S3 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q2s3_docs\S2017Q2S3_PrimeGatorNRC10.sql

*/

:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s3_docs\RTP-2395 Sampling - re-survey exclusion rule.sql" 

:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s3_docs\SurveyRules RT from HCAHPS.sql" 

--:r "\AtlasReleaseRT2017Q2\SprintRtp2017q2s3_docs\ATL-1450 skip instructions are no longer Bolded.sql" --already released
