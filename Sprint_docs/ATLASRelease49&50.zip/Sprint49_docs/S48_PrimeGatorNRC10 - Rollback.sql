/*

Sprint 48 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint49_docs\S48_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease47&48\Sprint49_docs\S49 ATL-395 Update CompletenessCheck ROLLBACK.sql"

:r "\ATLASRelease47&48\Sprint49_docs\S49 ATL-395 Hospice Language-Speak Question_ROLLBACK.sql"