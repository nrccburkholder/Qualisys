/*

Sprint 49 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint49_docs\S49_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease49&50\Sprint49_docs\S49 ATL-386 CGCAHPS Practice Site-Facility impact on Medusa - Rollback.sql"
