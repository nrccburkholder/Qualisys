/*

Sprint 48 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint49_docs\S48_PrimeGatorNRC10.sql

*/

--:r "\ATLASRelease47&48\Sprint49_docs\S49 ATL-395 Run Test Prints for Hospice QuestionCore change.sql"

:r "\ATLASRelease47&48\Sprint49_docs\S49 ATL-395 Update CompletenessCheck.sql"

:r "\ATLASRelease47&48\Sprint49_docs\S49_ATL-395 Hospice Language-Speak Question.sql"