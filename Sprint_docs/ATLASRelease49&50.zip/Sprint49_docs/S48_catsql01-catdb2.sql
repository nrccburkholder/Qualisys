/*

Sprint 48 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint49_docs\S48_catsql01-catdb2.sql

*/

:r "\ATLASRelease47&48\Sprint49_docs\S49 ATL-395 Hospice Language-Speak Question CEM.sql"

