/*

Sprint 49 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\Sprint48_docs\S49_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease49&50\Sprint48_docs\S48 ATL-157 Implement OAS Systematic Sampling Algorithm - Rollback.sql"
