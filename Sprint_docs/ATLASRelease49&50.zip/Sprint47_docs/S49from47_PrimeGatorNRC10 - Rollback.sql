/*

Sprint 49 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint47_docs\S49_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease49&50\Sprint47_docs\S47 ATL-157 Systematic Outgo and Proportion tables_rollback.sql"

:r "\ATLASRelease49&50\Sprint47_docs\S47 ATL-242 DB stored procedures for OAS sampling_Rollback.sql"
