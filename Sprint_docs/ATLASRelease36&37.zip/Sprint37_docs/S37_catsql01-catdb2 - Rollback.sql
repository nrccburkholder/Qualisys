/*

Sprint 37 SQLCMD Script for Hulk/Longhorn/Medusa

\GIT2015\Sprint_docs\Sprint37_docs\S37_catsql01-catdb2 - Rollback.sql

Chris Burkholder

*/

:r "\GIT2015\Sprint_docs\Sprint37_docs\S37_US8 CEM Hospice XML v 2.0 ROLLBACK.sql"
