/*

Sprint 37 SQLCMD Script for Hulk/Longhorn/Medusa

\GIT2015\Sprint_docs\Sprint37_docs\S37_HulkLonghornMedusa - Rollback.sql

Chris Burkholder

*/

:r "\GIT2015\Sprint_docs\Sprint37_docs\S37_US10.1 Add ICD10 to HHCAHPS Export Files - Rollback.sql"
