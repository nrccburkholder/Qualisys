/*

Sprint 36 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint36_docs\S36_catsql01-catdb2.sql

Chris Burkholder

*/

:r "\ATLASRelease36&37\Sprint36_docs\S36_US17.1 Add Hospice Disavowal disposition to NRC_Datamart.sql"

:r "\ATLASRelease36&37\Sprint36_docs\S36_US12 CEM Hospice XML v 1.3.sql"

-- already deployed ?? :r "\ATLASRelease36&37\Sprint36_docs\S36_US11 CAHPS Hospice exclude caregiverresponse section.sql"