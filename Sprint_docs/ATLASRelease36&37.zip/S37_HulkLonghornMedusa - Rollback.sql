/*

Sprint 37 SQLCMD Script for Hulk/Longhorn/Medusa

\Sprint_docs\Sprint37_docs\S37_HulkLonghornMedusa - Rollback.sql

Chris Burkholder

*/

:r "\ATLASRelease36&37\Sprint37_docs\S37_US10.1 Add ICD10 to HHCAHPS Export Files - Rollback.sql"
