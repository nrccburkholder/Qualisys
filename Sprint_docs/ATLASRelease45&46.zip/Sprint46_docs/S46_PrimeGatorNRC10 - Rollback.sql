/*

Sprint 46 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint46_docs\S46_PrimeGatorNRC10 - Rollback.sql

Chris Burkholder

*/

:r "\ATLASRelease45&46\Sprint46_docs\S46 US9 Lock Down CG CAHPS Survey Type ROLLBACK.sql"

:r "\ATLASRelease45&46\Sprint46_docs\S46 US11 Sample Plan Quick Hits ROLLBACK.sql"

:r "\ATLASRelease45&46\Sprint46_docs\S46 US16 Delete Groups & Sites - Rollback.sql"
