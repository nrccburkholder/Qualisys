/*

Sprint 68 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\Sprint68_docs\S68_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1363 Hospice CAHPS Survey Lang Question Update - Completness Check - ROLLBACK.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1363 Hospice CAHPS Survey Lang Question Update - ROLLBACK.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1396 Fix OAS Sampling for Two Encs on Same Day - ROLLBACK.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1402 HCAHPS Calculate Proportion and Outgo Using Distinct Pops - ROLLBACK.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1404 IsHomeless Metafield - ROLLBACK.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 RTP-1145 Automate the study data structure creation process for an HCAHPS client - Rollback.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 RTP-1145 ee_makebigview - Rollback.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 RTP-1145 HCAHPS DG Solutions Survey Subtype - Rollback.sql"