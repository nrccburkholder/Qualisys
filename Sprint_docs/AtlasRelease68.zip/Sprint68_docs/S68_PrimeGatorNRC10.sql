/*

Sprint 68 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint68_docs\S68_PrimeGatorNRC10.sql

*/

--:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1363 Hospice CAHPS Survey Lang Question Update - Completness Check.sql" --hold until later per Dana

--:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1363 Hospice CAHPS Survey Lang Question Update.sql" --hold until later per Dana

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1396 Fix OAS Sampling for Two Encs on Same Day.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1402 HCAHPS Calculate Proportion and Outgo Using Distinct Pops.sql"

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1404 IsHomeless Metafield.sql"

