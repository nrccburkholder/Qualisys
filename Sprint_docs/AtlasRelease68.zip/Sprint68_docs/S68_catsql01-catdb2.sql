/*

Sprint 68 SQLCMD Script for CatSql01-CatDB2

\Sprint_docs\Sprint68_docs\S68_catsql01-catdb2.sql

*/

:r "\ATLASRelease68\Sprint68_docs\S68 ATL-1363 Hospice CAHPS Survey Lang Question Update -CEM.sql"

