/*

Sprint 46 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint46_docs\S46_catsql01-catdb2.sql

*/


:r "\ATLASRelease45&46\Sprint46_docs\S46_US7.1 etl_ProcessSamplePopulationDispositionLogRecords_ROLLBACK.sql"


