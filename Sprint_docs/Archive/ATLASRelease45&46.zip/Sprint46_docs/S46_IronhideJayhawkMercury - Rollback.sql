/*

Sprint 46 SQLCMD Script for Ironhide/Jayhawk/Mercury

\Sprint_docs\Sprint46_docs\S46_IronhideJayhawkMercury - Rollback.sql

Chris Burkholder

*/

:r "\ATLASRelease45&46\Sprint46_docs\S46 US16 Delete Groups & Sites NRCAuth - Rollback.sql"
