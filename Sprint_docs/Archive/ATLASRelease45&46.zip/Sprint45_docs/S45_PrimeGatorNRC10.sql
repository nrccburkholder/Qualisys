/*

Sprint 45 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint45_docs\S45_PrimeGatorNRC10.sql

Chris Burkholder

*/

:r "\ATLASRelease45&46\Sprint45_docs\S45 US11 French Skip Instructions Question Variations CIHI.sql"

