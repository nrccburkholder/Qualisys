/*

Sprint 2017 Q3 S1 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q3s1_docs\S2017Q3S1_PrimeGatorNRC10 - Rollback.sql

*/

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q3s1_docs\RTP-3587 Don't Exclude TOCL from Sampling for ACO & MIPS - rollback.sql" 

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q3s1_docs\RTP-3718 ICH Skip Instruction Text - Rollback.sql" 

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q3s1_docs\RTP-3590 Report Records TOCLd During Generation - rollback.sql" 

