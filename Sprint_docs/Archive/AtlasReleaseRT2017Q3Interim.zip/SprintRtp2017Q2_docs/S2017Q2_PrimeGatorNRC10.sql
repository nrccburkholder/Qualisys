/*

Sprint 2017 Q2 S4 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\SprintRtp2017q2_docs\S2017Q2_PrimeGatorNRC10.sql

*/

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q2_docs\RTP-2347 - OAS CAHPS Blank Survey Processing - CheckForCAHPSIncompletes.sql" 

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q2_docs\RTP-2347 - OAS CAHPS Blank Survey Processing - CheckForMostCompleteUsablePartials.sql" 

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q2_docs\RTP-2347 - OAS CAHPS Blank Survey Processing - QFResponseCount.sql"

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q2_docs\RTP-2347 - update SurveyTypeQuestionMapping.sql"

:r "\AtlasReleaseRT2017Q3Interim\SprintRtp2017q2_docs\RTP-3362 Update Survey Validation - HHCAHPS Languages.sql"