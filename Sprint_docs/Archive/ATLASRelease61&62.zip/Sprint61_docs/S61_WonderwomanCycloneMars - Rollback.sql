/*

Sprint 61 SQLCMD Script for Wonderwoman/Cyclone/Mars

\Sprint_docs\Sprint61_docs\S61_WonderwomanCycloneMars - Rollback.sql

*/

:r "\ATLASRelease61&62\Sprint61_docs\S61 ATL-1029 Hospice Validation Report - number of decedents MARS - ROLLBACK.sql"

