/*

Sprint 62 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint62_docs\S62_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease61&62\Sprint62_docs\S62 ATL-1103 Disposition TOCLs for ACO & PQRS NRC10.sql"

:r "\ATLASRelease61&62\Sprint62_docs\S62 ATL-1103 Disposition TOCLs for ACO & PQRS - BACKPOPULATE - NRC10.sql"

:r "\ATLASRelease61&62\Sprint62_docs\S62 ATL-1002 Eliminate Hospice CAHPS Guardian Flag DQ.sql"
