/*

Sprint 41 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint41_docs\S41_PrimeGatorNRC10 - rollback.sql

Chris Burkholder

*/

--:r "\ATLASRelease41&42\Sprint41_docs\S41 US20 T1 OAS CAHPS Skip Instructions - ROLLBACK.sql" already deployed

--:r "\ATLASRelease41&42\Sprint41_docs\S41_US21 OAS Keep Most Complete Return ROLLBACK.sql" already deployed

:r "\ATLASRelease41&42\Sprint41_docs\S41_US16.4.2 OCS HH process update files - ROLLBACK.sql"