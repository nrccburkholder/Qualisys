/*

Sprint 42 SQLCMD Script for Wonderwoman/Cyclone/Mars

\Sprint_docs\Sprint42_docs\S42_WonderwomanCycloneMars.sql

Chris Burkholder

*/


:r "\ATLASRelease41&42\Sprint42_docs\S42_S39_R18_QLoader_LD_SaveSource.sql"