/*

Sprint 36 SQLCMD Script for Ratchet/Irish/Minerva

\Sprint_docs\Sprint36_docs\S36_RatchetIrishMinerva.sql

Chris Burkholder

*/

:r "\ATLASRelease36&37\Sprint36_docs\S36_US18 HH ICD-10 Transform.sql"

