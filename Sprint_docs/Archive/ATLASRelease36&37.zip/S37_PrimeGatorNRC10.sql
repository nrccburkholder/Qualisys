/*

Sprint 37 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint37_docs\S37_PrimeGatorNRC10.sql

Chris Burkholder

*/

--CHG0032216 11/02/2015 :r "\ATLASRelease36&37\Sprint37_docs\S37 INC0050205 FormLayout Print Mockup Fix.sql"

--CHG0032210 10/29/2015 :r "\ATLASRelease36&37\Sprint37_docs\S37 US3 T1 Si Contesto Restore #.sql"

--CHG0032251 11/17/2015 :r "\ATLASRelease36&37\Sprint37_docs\S37 US6 T1 Skip Instructions Question Variations.sql"

:r "\ATLASRelease36&37\Sprint37_docs\S37_US7.1 Add Missing Caregiver disposition_QP_Prod.sql"

:r "\ATLASRelease36&37\Sprint37_docs\S37_US7.2 QCL_Samp_ScheduleSampleSetGeneration.sql"