/*

Sprint 65 SQLCMD Rollback Script for Wonderwoman/Cyclone/Mars

\Sprint_docs\Sprint65_docs\S65_WonderwomanCycloneMars - Rollback.sql

*/

:r "\ATLASRelease65&66\Sprint65_docs\S65 ATL-1284 AddressCleaning MARS - ROLLBACK.sql"

