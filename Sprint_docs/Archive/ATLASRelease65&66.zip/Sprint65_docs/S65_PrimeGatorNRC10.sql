/*

Sprint 65 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint65_docs\S65_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease65&66\Sprint65_docs\S65 ATL-1284 AddressCleaning_NRC10.sql"

:r "\ATLASRelease65&66\Sprint65_docs\S65_ATL-1073 Modify Qualisys Explorer Application for Proxy Return handling.sql"

:r "\ATLASRelease65&66\Sprint65_docs\S65_ATL-1265 Activate PIT Checkbox for CG-CAHPS Survey Type.sql"
