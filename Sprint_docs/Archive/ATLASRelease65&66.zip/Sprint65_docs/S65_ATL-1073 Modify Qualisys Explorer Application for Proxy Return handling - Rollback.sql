/*

S65_ATL-1073 Modify Qualisys Explorer Application for Proxy Return handling - Rollback.sql

Chris Burkholder

12/28/2016

DROP PROCEDURE [dbo].[QCL_LogDispositionByLitho] 

*/

DROP PROCEDURE [dbo].[QCL_LogDispositionByLitho] 

GO