/*

Sprint 65 SQLCMD Rollback Script for Ratchet/Irish/Minerva

\Sprint_docs\Sprint65_docs\S65_RatchetIrishMinerva - Rollback.sql

*/

:r "\ATLASRelease65&66\Sprint65_docs\S65 ATL-1284 AddressCleaning Minerva - ROLLBACK.sql"
