/*

Sprint 65 SQLCMD Script for Ratchet/Irish/Minerva

\Sprint_docs\Sprint65_docs\S65_RatchetIrishMinerva.sql

*/

:r "\ATLASRelease65&66\Sprint65_docs\S65 ATL-1284 AddressCleaning Minerva.sql"
