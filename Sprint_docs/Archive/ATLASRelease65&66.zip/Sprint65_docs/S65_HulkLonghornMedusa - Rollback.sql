/*

Sprint 65 SQLCMD Rollback Script for Hulk/Longhorn/Medusa

\Sprint_docs\Sprint65_docs\S65_HulkLonghornMedusa - Rollback.sql

*/

:r "\ATLASRelease65&66\Sprint65_docs\S65 ATL-1139 Calculate Lag Time for Final Dispo From DRG Update Medusa - Rollback.sql"

