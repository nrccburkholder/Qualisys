/*

Sprint 65 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\Sprint65_docs\S65_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease65&66\Sprint65_docs\S65 ATL-1284 AddressCleaning NRC10 - ROLLBACK.sql"

:r "\ATLASRelease65&66\Sprint65_docs\S65_ATL-1073 Modify Qualisys Explorer Application for Proxy Return handling - Rollback.sql"

:r "\ATLASRelease65&66\Sprint65_docs\S65_ATL-1265 Activate PIT Checkbox for CG-CAHPS Survey Type - Rollback.sql"
