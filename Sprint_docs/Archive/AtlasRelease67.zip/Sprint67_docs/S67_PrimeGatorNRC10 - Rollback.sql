/*

Sprint 67 SQLCMD Rollback Script for Prime/Gator/NRC10

\Sprint_docs\Sprint67_docs\S67_PrimeGatorNRC10 - Rollback.sql

*/

:r "\ATLASRelease67\Sprint67_docs\S67 ATL-1219 GCCahps Validation Update ROLLBACK.sql"

:r "\ATLASRelease67\Sprint67_docs\S67 ATL-1269 GCCahps Completeness ROLLBACK.sql"

--:r "\ATLASRelease67\Sprint67_docs\S67 ATL-1370 Automate the study data structure creation process for an HCAHPS client - Rollback.sql"