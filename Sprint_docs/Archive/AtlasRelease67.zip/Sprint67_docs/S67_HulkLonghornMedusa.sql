/*

Sprint 67 SQLCMD Script for Hulk/Longhorn/Medusa

\Sprint_docs\Sprint67_docs\S67_HulkLonghornMedusa.sql

*/

:r "\ATLASRelease67\Sprint67_docs\S67  ATL-1219 CG Update Patient Submission Procs.sql"

