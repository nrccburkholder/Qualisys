/*

Sprint 56 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint56_docs\S58fromS56_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease57&58\Sprint56_docs\S56 ATL-719 OAS CAHPS Resurvey Exclusion.sql"

:r "\ATLASRelease57&58\Sprint56_docs\S56_ATL-742 datExpireUsage in ETL - NRC10.sql" -- pending UAT in Sprint 58.  Delaying