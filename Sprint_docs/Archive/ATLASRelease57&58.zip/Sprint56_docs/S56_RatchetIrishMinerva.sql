/*

Sprint 56 SQLCMD Script for Ratchet/Irish/Minerva

\Sprint_docs\Sprint56_docs\S56_RatchetIrishMinerva.sql

*/

:r "\ATLASRelease55&56\Sprint56_docs\S56 ATL-228 Add CCN to HHCAHPS Importer Admin.sql"
