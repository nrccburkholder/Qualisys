/*

Sprint 56 SQLCMD Script for Prime/Gator/NRC10

\Sprint_docs\Sprint56_docs\S56_PrimeGatorNRC10.sql

*/

:r "\ATLASRelease55&56\Sprint56_docs\S56 ATL-708 Phone Vendor Cancel Fix.sql"

:r "\ATLASRelease55&56\Sprint56_docs\S56 ATL-715 Vovici Svc Resending Participants.sql"

--OC Release on 9/1/2016 :r "\ATLASRelease55&56\Sprint56_docs\S56 ATL-719 OAS CAHPS Resurvey Exclusion.sql"

--:r "\ATLASRelease55&56\Sprint56_docs\S56_ATL-742 datExpireUsage in ETL - NRC10.sql" -- not sufficiently UAT'd.  Delaying