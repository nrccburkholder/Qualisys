/*

Sprint 57 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint57_docs\S57_catsql01-catdb2.sql

*/

:r "\ATLASRelease57&58\Sprint57_docs\S57 ATL-777 OAS Proxy Surveys CATDB.sql"
