/*

Sprint 40 SQLCMD Script for catsql01-catdb2

\Sprint_docs\Sprint40_docs\S40_catsql01-catdb2.sql

*/


--:r "\ATLASRelease40\Sprint40_docs\S40_US23 CEM ICHCAHPS Language Speak Update.sql" already done

:r "\ATLASRelease40\Sprint40_docs\S40_US22.2 CEM Hospice XML v 2.1.sql"